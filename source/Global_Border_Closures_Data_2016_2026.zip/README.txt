Global Border Closures Atlas — 2026.10.25-rec50

The two-tab Master workbook is the readable register. The native JSON keeps current records, phases, sources and reviewed release metadata.
Supporting historical tables are explicitly labelled by native-table provenance; they are preserved history, not new current claims.
The CSV files are projections. Use JSON for complete source/review histories and original-versus-current values.
Held phases remain in the evidence but have no numeric duration. Policy dates, announced windows, observations and operational spells remain distinct.
Geography references retained in the research envelope are historical inputs. The current scope/location review is supplied separately as crossing-map-review.json.
Canonical research state: d9036cb8d241de5bcef39e99c6d97d62e573b59e5e02097a79a10cbf355eb39e
Native release input SHA-256: 5baf139f914593184ed2eee3f5a9dfd783cb264332415f98e645b409c314a415
